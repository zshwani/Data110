# This is Rebin

## Data 110

1. **I like hiking**
2. *I am origially from Kurdistan*


Okay... I know I have to do more.. will be back to later after class, still have time till end of the week.

-[]

-[]


![My student watching a quilt in DC](IMG_2046.JPG)
